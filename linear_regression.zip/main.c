
    #include <stdio.h>

    float prediction(float *features, int n_feature);

    int main() {
        float features[] = {2.2, 3.19, 6.56};
        int n_feature = 3;
        float result = prediction(features, n_feature);
        printf("Pr�diction : %f\n", result);
        return 0;
    }
        